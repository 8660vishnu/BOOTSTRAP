const startbutton = document.getElementById('start-btn')
const nextbutton = document.getElementById('next-btn')
 
const questionContainerElement = document.getElementById('question-container')
const questionElement = document.getElementById('question')
const answerButtonsElement = document.getElementById('answer-button')

let shuffledQuestions,currentQuestion;
let quizScore=0;

function resetState(){
    clearStatusClass(document.body)
    nextbutton.classList.add('hide')
    while(answerButtonsElemewnt.firstChild){
        answerButtonsElement.removeChild(answerButtonsElement.firstChild)
    }

    }


function selectAnswer(e){
    const selectedButton=e.target
    const correct = selectedButton.dataset.correct

    setStatusClass(document.body,correct)
    Array.from(answerButtonsElement.children).forEach((button)=>{

    })
    if(shuffledQuestions.length > currentQuestionIndex +1){
        nextbutton.classList.remove("hide")
    }
   else{
    startButton.innerText ="restart"
    startButton.classList.remove("hide")

   }
   if(selectedButton.dataset=correct){
    quizScore++
   }
   document.getElementById('right-answer').innerText=quizScore
}

function setStatusClass(element,correct){
    clearStatusClass(element)
    if(correct)
    {
        element.classList.add("correct")
    }
    else{
        element.classList.add("wrong")
    }
    }




function clearStatusClass(element){
    element.classList.remove('correct')
    element.classList.remove('wrong')
}
const questions=[
{
    question: 'which one of these is a javascript framework?',
    answers :[
        { text:'python',correct:false},
        { text:'django',correct:false},
        { text:'React',correct:true},
        { text:'eclipse',correct:false},

        
    ],
},
{
question:'who is the primeminister of india?',
answer :[
    { text:'Modi',correct:true},
    { text:'Rahul gandhi',correct:false},
    
    
],
},
{
    question:'what is 4+7?',
    answer :[
        { text:'11',correct:true},
        { text:'8',correct:false},
        
        
    ],
    },
]
